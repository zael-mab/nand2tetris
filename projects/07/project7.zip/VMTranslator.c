/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zael-mab <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/19 07:06:39 by zael-mab          #+#    #+#             */
/*   Updated: 2021/11/19 07:06:41 by zael-mab         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "vm.h"


///////////////////////////////////////////////////////
void	*ft_memset(void *b, int c, size_t len)
{
	size_t	i;

	i = 0;
	while (i < len)
		((unsigned char *)b)[i++] = (unsigned char)c;
	return (b);
}

void	ft_bzero(void *s, size_t n)
{
	ft_memset(s, '\0', n);
}


char	*ft_strjoin(char const *s1, char const *s2)
{
	size_t	i;
	size_t	t;
	char	*s0;

	i = 0;
	t = 0;
	if (s1 && s2)
	{
		if ((s0 = ft_strnew(strlen(s1) + strlen(s2))))
		{
			while (s1[i])
			{
				s0[i] = s1[i];
				i++;
			}
			while (s2[t])
			{
				s0[i] = s2[t];
				t++;
				i++;
			}
			return (s0);
		}
	}
	return (NULL);
}

char	*ft_strdup(char *s1)
{
	char	*str0;
	size_t	j;

	if (!(str0 = (char *)malloc(strlen(s1) + 1)))
		return (NULL);
	j = 0;
	while (s1[j])
	{
		str0[j] = s1[j];
		j++;
	}
	str0[j] = '\0';
	return (str0);
}


char	*ft_strsub(char const *s1, unsigned int start, size_t len)
{
	char	*s0;
	size_t	j;

	j = 0;
	if (!s1 || !(s0 = (char *)malloc(len + 1 * sizeof(*s0))))
		return (NULL);
	while (j < len)
	{
		s0[j] = s1[j + start];
		j++;
	}
	s0[j] = '\0';
	return (s0);
}


void	ft_strdel(char **as)
{
	if (as)
	{
		free(*as);
		*as = NULL;
	}
}


void	*ft_memalloc(size_t size)
{
	char	*r;
	size_t	j;

	j = 0;
	if (!(r = (char *)malloc(size * sizeof(*r))))
		return (NULL);
	while (j < size)
	{
		r[j] = '\0';
		j++;
	}
	return (r);
}

char	*ft_strnew(size_t size)
{
	char	*r;
	size_t	j;

	j = 0;
	if (!(r = (char *)malloc(size + 1 * sizeof(*r))))
		return (NULL);
	while (j <= size)
		r[j++] = '\0';
	return (r);
}

char	*ft_strtrim(char const *s)
{
	int i;
	int j;

	i = 0;
	if (s)
	{
		j = strlen(s) - 1;
		while (s[i] && (s[i] == ' ' || s[i] == '\n' || s[i] == '\t' || s[i] == 13))
			i++;
		while (j > i && (s[j] == ' ' || s[j] == '\n' || s[j] == '\t' || s[j] == 13))
			j--;
		return (ft_strsub(s, i, j - i + 1));
	}
	return (NULL);
}



static	int	ft_cc(char const *s, char c, int i)
{
	int j;

	j = 0;
	while (s[i] && s[i] != c)
	{
		j++;
		i++;
	}
	return (j);
}

static	int	ft_wc(char const *s, char c)
{
	int j;
	int i;
	int f;

	i = 0;
	j = 0;
	f = 0;
	while (s[i])
	{
		if (s[i] != c && f == 0)
		{
			j++;
			f = 1;
		}
		else if (s[i] == c)
			f = 0;
		i++;
	}
	return (j);
}

char		**ft_strsplit(char const *s, char c)
{
	int		j;
	int		i;
	int		k;
	char	**str;

	i = 0;
	j = 0;
	if (!s || !(str = (char **)malloc(sizeof(char*) * (ft_wc(s, c) + 1))))
		return (NULL);
	while (s[i])
	{
		while (s[i] == c && s[i])
			i++;
		if (s[i])
		{
			k = 0;
			if (!(str[j] = ft_strnew(ft_cc(s, c, i))))
				return (NULL);
			while (s[i] != c && s[i])
				str[j][k++] = s[i++];
			str[j++][k] = '\0';
		}
	}
	str[j] = NULL;
	return (str);
}



char	*ft_strchr(const char *s, int c)
{
	char	*n;
	int		j;

	j = 0;
	n = (char *)s;
	while (n[j])
	{
		if (n[j] == (char)c)
			return (n + j);
		j++;
	}
	if (n[j] == c)
		return (&n[j]);
	return (0);
}



void	ft_memdel(void **ap)
{
	if (ap)
	{
		free(*ap);
		*ap = NULL;
	}
}

static	void	ft_update(char **tab, char *temp)
{
	char	*del;

	del = ft_strdup(temp);
	ft_strdel(tab);
	*tab = del;
}

/*
** this function manage the possible cases,
** in the case when read arrives to the end of the file;
*/

static int		ft_lastline(char **tab, char **line, int nbr)
{
	if (nbr == -1)
		return (-1);
	if (nbr == 0 && !strlen(*tab))
		return (0);
	*line = *tab;
	*tab = NULL;
	return (1);
}

int				get_next_line(const int fd, char **line)
{
	char		*temp;
	char		str[BUFF_SIZE + 1];
	static char *tab[FD_MAX];
	int			nbr;

	if (fd < 0 || BUFF_SIZE < 0 || fd > FD_MAX || !line)
		return (-1);
	nbr = 1;
	if (tab[fd] == NULL)
		tab[fd] = ft_strnew(0);
	while (((temp = ft_strchr(tab[fd], '\n')) == NULL) &&\
			((nbr = read(fd, str, BUFF_SIZE)) > 0))
	{
		str[nbr] = '\0';
		temp = tab[fd];
		tab[fd] = ft_strjoin(tab[fd], str);
		ft_strdel(&temp);
	}
	if (nbr < 1)
		return (ft_lastline(&tab[fd], line, nbr));
	*temp = '\0';
	*line = ft_strdup(tab[fd]);
	ft_update(&tab[fd], temp + 1);
	return (1);
}



////////////////////////////////////////////////////
void    init_memory_segment(t_memory_segments *segments)
{
    segments->sp = 0;
    segments->local = 1;
    segments->arg = 2;
    segments->t_his = 3;
    segments->that = 4; 
    segments->tmp = 5;              // tmp < 12
}

void    trans(t_head *head, t_memory_segments *segments)
{
    t_node *inst;

    init_memory_segment(segments);
    inst = head->first;
    while (inst)
    {
        if (!inst->arith)
        {
            if (inst->op == PUSH)
            {
                // constant
                if (inst->segment == CONST)
                    print_code(*inst, *segments, 0, 0);

                // ///////
                if (inst->segment == ARG)
                    print_code(*inst, *segments,segments->arg, 1);
                if (inst->segment == LCL)
                    print_code(*inst, *segments,segments->local, 1);
                if (inst->segment == THIS)
                    print_code(*inst, *segments,segments->t_his, 1);
                if (inst->segment == THAT)
                    print_code(*inst, *segments,segments->that, 1);
                
                // 
                if (inst->segment == PTR)
                {
                    if (!inst->index)
                        print_code(*inst, *segments, segments->t_his, 3);
                    else
                        print_code(*inst, *segments, segments->that, 3);
                }

                // 
                if (inst->segment == TEMP)
                    print_code(*inst, *segments, segments->tmp + inst->index, 3);


                // 
                if (inst->segment == STATIC)
                {
                    dprintf (segments->fd,"//%s\n@%s.%d\nD=M\n@%d\nA=M\nM=D\n@%d\nM=M+1\n",
                        inst->command, head->file_name, inst->index, segments->sp, segments->sp);
                }
            }
            if (inst->op == POP)
            {

                if (inst->segment == ARG)
                    print_code(*inst, *segments, segments->arg, 2);
                if (inst->segment == LCL)
                    print_code(*inst, *segments, segments->local, 2);
                if (inst->segment == THAT)
                    print_code(*inst, *segments, segments->that, 2);
                if (inst->segment == THIS)
                    print_code(*inst, *segments, segments->t_his, 2);

                // 
                if (inst->segment == PTR)
                {
                    if (!inst->index)
                        print_code(*inst, *segments, segments->t_his, 4);
                    else
                        print_code(*inst, *segments, segments->that, 4);
                }

                //
                if (inst->segment == TEMP)
                    print_code(*inst, *segments, segments->tmp + inst->index, 4);

                // 
                if (inst->segment == STATIC)
                {
                    dprintf (segments->fd, "//%s\n@%d\nAM=M-1\nD=M\n@%s.%d\nM=D\n",
                    inst->command, segments->sp, head->file_name, inst->index);
                }
            }
        }
        /////////////  /////////////////////////////////////////
        if (inst->arith == 1)
        {
            if (inst->op == ADD)
            {
                dprintf(segments->fd,"//%s\n@%d\nAM=M-1\nD=M\n@%d\nAM=M-1\nD=M+D\n@%d\nA=M\nM=D\n@%d\nM=M+1\n",
                 inst->command, segments->sp, segments->sp, segments->sp, segments->sp);
            }
            if (inst->op == SUB)
            {
                dprintf(segments->fd,"//%s\n@%d\nAM=M-1\nD=M\n@%d\nAM=M-1\nD=M-D\n@%d\nA=M\nM=D\n@%d\nM=M+1\n",
                 inst->command, segments->sp, segments->sp, segments->sp, segments->sp);
            }
            if (inst->op == NEG)
            {
                dprintf(segments->fd,"//%s\n@%d\nAM=M-1\nM=-M\n@%d\nM=M+1",
                 inst->command, segments->sp, segments->sp);
            }
            // //   ????????
            if (inst->op == EQ)
            {
                segments->mnemonic = ft_strdup("JNE");
                print_code(*inst, *segments, 0, 5);
                free(segments->mnemonic);
            }
            //////
            if (inst->op == GT)
            {
                segments->mnemonic = ft_strdup("JLE");
                print_code(*inst, *segments, 0, 5);
                free(segments->mnemonic);
            }
            if (inst->op == LT)
            {
                segments->mnemonic = ft_strdup("JGE");
                print_code(*inst, *segments, 0, 5);
                free(segments->mnemonic);
            }
            // //
            if (inst->op == AND)
            {
                print_code(*inst, *segments, '&', 6);
            }
            if (inst->op == OR)
            {
                print_code(*inst, *segments, '|', 6);
            }
            //
            if (inst->op == NOT)
            {
                dprintf(segments->fd, "//%s\n@%d\nA=M-1\nM=!M\n",
                 inst->command, segments->sp);
            }

        }
        inst = inst->next;
    }

}


///////////////////////////////////////////
void    print_code(t_node inst, t_memory_segments segments, int x, int sw)
{
    if (sw == 0)
        dprintf(segments.fd,"//%s\n@%d\nD=A\n@%d\nA=M\nM=D\n@%d\nM=M+1\n",
         inst.command, inst.index, segments.sp, segments.sp);
    if (sw == 1)
        dprintf(segments.fd, "//%s\n@%d\nD=A\n@%d\nA=M+D\nD=M\n@%d\nA=M\nM=D\n@%d\nM=M+1\n",
            inst.command, inst.index, x, segments.sp, segments.sp);
    if (sw == 2)
        dprintf (segments.fd, "//%s\n@%d\nD=A\n@%d\nM=M+D\n@%d\nAM=M-1\nD=M\n@%d\nA=M\nM=D\n@%d\nD=A\n@%d\nM=M-D\n",
            inst.command, inst.index, x, segments.sp, x, inst.index, x);
    if (sw == 3)
        dprintf(segments.fd,"//%s\n@%d\nD=M\n@%d\nA=M\nM=D\n@%d\nM=M+1\n",
         inst.command, x, segments.sp, segments.sp);
    if (sw == 4)
        dprintf(segments.fd,"//%s\n@%d\nAM=M-1\nD=M\n@%d\nM=D\n",
        inst.command, segments.sp, x);
    if (sw == 5)
        dprintf(segments.fd, "//%s\n@%d\nAM=M-1\nD=M\n@%d\nAM=M-1\nD=M-D\n@FALSE%d\nD;%s\n@%d\nA=M\nMD=%d\n@GO%d\n0;JMP\n(FALSE%d)\n@%d\nA=M\nM=0\n(GO%d)\n@%d\nM=M+1\n",
        inst.command, segments.sp, segments.sp, inst.pos, segments.mnemonic, segments.sp, (inst.op == EQ ? -1 : -1),inst.pos, inst.pos, segments.sp, inst.pos, segments.sp);
    if (sw == 6)
        dprintf(segments.fd, "//%s\n@%d\nAM=M-1\nD=M\n@%d\nAM=M-1\nD=D%cM\n@%d\nA=M\nM=D\n@%d\nM=M+1\n",
         inst.command, segments.sp, segments.sp, x,segments.sp, segments.sp);
            
}


///////////////////////////////////////////
void    init_newnode(t_node *newnode, t_vmdata data)
{
    newnode->op = data.op;
    newnode->segment = data.segment;
    newnode->index = data.index;
    newnode->command = ft_strdup(data.line);
    newnode->arith = data.arith;
    newnode->next = NULL;
}

void    add_last(t_head *head, t_vmdata *data)
{
    t_node *newnode;
    t_node *tmp;

    newnode = ft_memalloc(sizeof(t_node));
    init_newnode(newnode, *data);
    if (!head->first)
    {
        head->first = newnode;
        newnode->pos = 1;
        head->h_size = 1;
    }
    else
    {
        tmp = head->first;
        while (tmp->next != NULL)
            tmp = tmp->next;
        tmp->next = newnode;
        head->h_size++;
        newnode->pos = head->h_size;
    }
}


////////////////////////////////////////

int     set_segment(char *segment)
{
    if (strcmp(segment, "local") == 0)
        return (LCL);
    else if (strcmp(segment, "argument") == 0)
        return (ARG);
    else if (strcmp(segment, "this") == 0)
        return (THIS);
    else if (strcmp(segment, "that") == 0)
        return (THAT);
    else if (strcmp(segment, "constant") == 0)
        return (CONST);
    else if (strcmp(segment, "static") == 0)
        return (STATIC);
    else if (strcmp(segment, "temp") == 0)
        return (TEMP);
    else if (strcmp(segment, "pointer") == 0)
        return (PTR);
    else
        return (0);
}


int     set_op(char *op)
{
    if (strcmp(op, "add") == 0)
        return (ADD);
    else if (strcmp(op, "sub") == 0)
        return (SUB);
    else if (strcmp(op, "neg") == 0)
        return (NEG);
    else if (strcmp(op, "eq") == 0)
        return (EQ);
    else if (strcmp(op, "gt") == 0)
        return (GT);
    else if (strcmp(op, "lt") == 0)
        return (LT);
    else if (strcmp(op, "and") == 0)
        return (AND);
    else if (strcmp(op, "or") == 0)
        return (OR);
    else if (strcmp(op, "not") == 0)
        return (NOT);
    else
        return (0);
}


int     check_and_set(char *line, t_vmdata *data)
{
    char **tab;

    tab = ft_strsplit(line, ' ');

    if ((tab[0][0] == '/' && tab[0][1] == '/' ) || strlen(tab[0]) < 2)
        return (-1);
    else
    {

        data->op = set_op((tab[0]));
        if (data->op > 0)
            data->arith = 1;

        if (!data->op)
        {
            if (strcmp(tab[0], "push") == 0)
                data->op = PUSH;
            if (strcmp(tab[0], "pop") == 0)
                data->op = POP;
            
            if (data->op == 0)
            {
                printf ("syntax error!\n");
                return(0);
            }
            if ((data->op & POP) || (data->op & PUSH))
            {
                data->segment = set_segment(tab[1]);
                if (data->segment == 0)
                {
                    printf ("segment problem at line [%s]\n", line);
                    return (0);
                }
            }
            data->index = atoi(tab[2]);
        }
        
        if (data->op == 0)
        {
            if (strlen(line) > 1)
                printf ("|+++++[%s] |op problem at line|\n", line);
            return (0);
        }

    }
    ft_memdel((void **)tab);
    return (1);
}



int        f_name(t_head *vmcode, char *name, int x)
{
    int name_len;
    int jumper;

    name_len = strlen(name);
    jumper = name_len;
    char *tmp = ft_strdup(name);
    while(--jumper > 0 && x == 1)
    {
        if (tmp[jumper] == '/')
        {
            tmp += jumper + 1;
            break;
        }

    }
    jumper = -1;
    while (tmp[++jumper])
    {

        if (tmp[jumper] == '.' && !strcmp(tmp + jumper + 1, "vm"))
            break ;
    }
    if (jumper == name_len)
        return (0);
    else
    {
        vmcode->file_name = (strncpy(ft_strnew(jumper), tmp, jumper));
        return(1);
    }
}

int main (int ac, char **av)
{
    if (ac == 2)
    {

        int fd;
        t_head *vmcode;
        t_vmdata *data;

        vmcode = ft_memalloc(sizeof (t_head));
        ft_bzero(vmcode , sizeof(t_head));

        data = ft_memalloc (sizeof (t_vmdata));
        bzero(data, sizeof(t_vmdata));

        if (!f_name(vmcode, av[1], 1))
        {
            printf ("Error file extention...!\n");
            return (0);
        }

        int i;
        fd = open(av[1], O_RDONLY);
        while (get_next_line(fd, &data->line) > 0)
        {
            char *tmp = ft_strtrim(data->line);
            free (data->line);
            data->line = tmp;
            if (strlen (data->line))
            {
                i = check_and_set (data->line, data);
                if (i > 0)
                    add_last(vmcode, data);
                if (i == 0)
                {
                    free(data->line);
                    return (0);
                }
            }
            free(data->line);
            bzero(data, sizeof(t_vmdata));
        }
        close(fd);
        
        t_memory_segments *segments;
        segments = ft_memalloc(sizeof(t_memory_segments));
        bzero(segments, sizeof(t_memory_segments));


        f_name(vmcode, av[1], 0);
        vmcode->file_name = ft_strjoin(vmcode->file_name, ".asm");
        
        segments->fd =  open (vmcode->file_name,O_CREAT | O_RDWR | O_TRUNC, 0600);

        f_name(vmcode, av[1], 1);
        trans(vmcode, segments);
        printf ("file [%s.asm] created\n", vmcode->file_name);
        close(segments->fd);
        
    }
    else
    {
        printf ("wrong arg!!!\n");
        return (0);
    }
}